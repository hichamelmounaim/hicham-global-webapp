<?php
/**
 * Core loader — bootstraps the Hicham Global Bridge plugin.
 *
 * Loads all core files, registry, modules, and admin components
 * at the appropriate WordPress lifecycle hook.
 *
 * @package Hicham GlobalBridge\Core
 */

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Initialize the Hicham Global Bridge plugin.
 *
 * Hooked on `plugins_loaded` to ensure all dependencies
 * (including third-party plugins) are available.
 *
 * @return void
 */
function HICHAM_GLOBAL_BRIDGE_init()
{

    // Core files.
    require_once HICHAM_GLOBAL_BRIDGE_PATH . 'core/helpers.php';
    require_once HICHAM_GLOBAL_BRIDGE_PATH . 'core/permissions.php';
    require_once HICHAM_GLOBAL_BRIDGE_PATH . 'core/plugin-detector.php';
    require_once HICHAM_GLOBAL_BRIDGE_PATH . 'core/api.php';

    // Registry.
    // Note: plugin-map.php and capabilities.php return arrays
    // and are loaded on demand by the functions that need them.

    // Modules.
    require_once HICHAM_GLOBAL_BRIDGE_PATH . 'modules/seo/seo-module.php';
    require_once HICHAM_GLOBAL_BRIDGE_PATH . 'modules/recipes/recipe-module.php';

    // Admin (only in admin context).
    if (is_admin()) {
        require_once HICHAM_GLOBAL_BRIDGE_PATH . 'admin/settings-page.php';
    }
}
add_action('plugins_loaded', 'HICHAM_GLOBAL_BRIDGE_init');
