<?php
/**
 * Uninstall handler for Hicham Global Bridge.
 *
 * Runs when the plugin is deleted (not deactivated) from WordPress.
 * Cleans up plugin-specific options only. Does NOT delete data
 * from third-party plugins (Rank Math, Tasty Recipes).
 *
 * @package Hicham GlobalBridge
 */

// Security check — only run during uninstall.
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Currently, V1 does not store any custom options.
// This file is in place to support future cleanup needs
// and to satisfy WordPress.org plugin directory requirements.
//
// Example (for future versions):
// delete_option( 'HICHAM_GLOBAL_BRIDGE_settings' );
// delete_site_option( 'HICHAM_GLOBAL_BRIDGE_settings' ); // For multisite.
