=== Hicham Global Bridge Integration ===
Contributors: Hicham Globalio
Tags: seo, recipes, rest-api, automation, rank-math, yoast, aioseo, wp-recipe-maker
Requires at least: 5.6
Tested up to: 6.9
Stable tag: 1.0.4
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Lightweight bridge plugin that connects the Hicham Global platform to compatible WordPress plugins via unified REST API endpoints.

== Description ==

**Hicham Global Bridge Integration** is a lightweight technical bridge designed to work with the [Hicham Global](https://hichamglobal.com/) automation platform. It enables Hicham Global to automatically fill SEO metadata and create recipe cards on your WordPress site by interfacing with popular WordPress plugins through a unified REST API.

= What This Plugin Does =

* **Plugin Detection** — Automatically detects compatible plugins installed on your WordPress site.
* **Unified REST API** — Exposes clean REST endpoints under `/wp-json/hicham_global/v1/` for the Hicham Global platform.
* **SEO Metadata** — Allows Hicham Global to set SEO titles, descriptions, focus keywords, Open Graph data, Twitter card data, canonical URLs, and robots directives via supported SEO plugins.
* **Recipe Cards** — Allows Hicham Global to create full recipe cards with ingredients, instructions, cooking times, nutrition data, and more via supported recipe plugins.

= Supported Plugins =

**SEO**

* **Rank Math SEO** — title, description, focus keyword, robots
* **Yoast SEO** — title, description, focus keyphrase, Open Graph, Twitter cards, canonical, robots
* **All in One SEO (AIOSEO)** — title, description, keywords, Open Graph, Twitter cards, canonical, robots

**Recipes**

* **Tasty Recipes** — full recipe creation with all fields including nutrition and featured image
* **WP Recipe Maker** — full recipe creation with structured ingredients/instructions, nutrition, and taxonomy terms
* **WP Delicious** — full recipe creation with ingredients, instructions, nutrition, and taxonomy terms

= How It Works =

This plugin does **not** replace WordPress functionality. It acts as a compatibility layer between the Hicham Global platform and third-party WordPress plugins. Hicham Global sends universal payloads via the REST API, and this plugin transforms them into the format required by each supported plugin.

When multiple supported plugins of the same type are active, the bridge uses a priority order: for SEO (Rank Math → Yoast → AIOSEO), for recipes (Tasty Recipes → WP Recipe Maker → WP Delicious).

= Requirements =

* WordPress 5.6 or later
* PHP 7.4 or later
* At least one supported plugin installed and active
* WordPress Application Password configured for API authentication

= Privacy =

This plugin does **not**:

* Collect or transmit personal data.
* Make external HTTP requests.
* Include tracking, analytics, or telemetry.
* Store any data beyond what WordPress and the supported plugins already manage.

The plugin only responds to authenticated REST API requests made by the Hicham Global platform or any authorized client.

For the Hicham Global platform privacy policy, visit [https://Hicham Global.io/privacy](https://Hicham Global.io/privacy).

== Installation ==

1. Upload the `hicham-global-bridge` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to the **Hicham Global Bridge** admin page to verify detected plugins and capabilities.
4. Configure your Hicham Global platform to connect to your site using Application Password authentication.

== Frequently Asked Questions ==

= Does this plugin work without the Hicham Global platform? =

The plugin will remain safely installed and inactive. It only processes requests when an authenticated client calls its REST API endpoints. It does not affect your site when unused.

= Does this plugin work without any supported plugins installed? =

The plugin will load and run, but the bridge status will show as inactive. SEO and recipe endpoints will return an appropriate error message indicating no supported adapter is available.

= Which SEO plugins are supported? =

Rank Math SEO, Yoast SEO, and All in One SEO (AIOSEO) are supported. If multiple SEO plugins are active, the bridge uses the first one found in priority order: Rank Math → Yoast → AIOSEO.

= Which recipe plugins are supported? =

Tasty Recipes, WP Recipe Maker, and WP Delicious are supported. If multiple recipe plugins are active, the bridge uses the first one found in priority order: Tasty Recipes → WP Recipe Maker → WP Delicious.

= Does this plugin send data to external servers? =

No. This plugin does not make any external HTTP requests. It only responds to incoming authenticated REST API requests.

= What permissions are required? =

All REST API endpoints require the requesting user to have the `edit_posts` capability. Authentication is handled via WordPress Application Password.

== Changelog ==

= 1.0.4 =
* Fixed WP Recipe Maker adapter: rewrote to use WPRM's native internal API (WPRM_Recipe_Sanitizer and WPRM_Recipe_Saver) so recipe data is processed through WPRM's own engine, ensuring correct rendering and cache consistency. Falls back to direct post meta writes on older WPRM versions where internal classes are unavailable.
* Fixed WP Recipe Maker adapter: added smart ingredient parsing — quantity, unit, and name are now extracted separately from plain-text lines (e.g. "2 cups flour" → amount: "2", unit: "cups", name: "flour"). Falls back to full line in name when parsing fails.
* Fixed WP Recipe Maker adapter: instruction steps are now wrapped in <p> tags as required by WPRM's renderer. Tags (course, cuisine, keyword) are now passed as part of the recipe data instead of via direct taxonomy calls.
* Fixed WP Delicious adapter: rewrote to write all recipe data to the single `delicious_recipes_metadata` meta key using camelCase field names — the only format WP Delicious reads. The previous implementation wrote individual meta keys that WP Delicious ignores entirely.
* Fixed WP Delicious adapter: added structured parsing for ingredients and instructions into WP Delicious's nested array format (sections → items).
* Fixed WP Delicious adapter: corrected shortcode from [dr id="X"] to [delicious-recipe id="X"].
* Fixed all recipe adapters: shortcode insertion now runs unconditionally — a missing or zero featured_media never prevents the recipe card from being inserted into the post.

= 1.0.3 =
* Added support for Yoast SEO: title, description, focus keyphrase, Open Graph title/description, Twitter card title/description, canonical URL, robots (noindex, nofollow, noarchive, nosnippet, noimageindex).
* Added support for All in One SEO (AIOSEO): title, description, keywords, Open Graph title/description, Twitter card title/description, canonical URL, robots (noindex, nofollow).
* Added support for WP Recipe Maker: full recipe creation with structured ingredients and instructions, nutrition data, cuisine/course/keyword taxonomy assignment, and shortcode insertion.
* Added support for WP Delicious: full recipe creation with ingredients, instructions, nutrition data, taxonomy assignment (cuisine, course, cooking method), and shortcode insertion.
* Updated Tasty Recipes adapter: added support for author name, keywords, category, method, cuisine, diet, serving size, featured image, and full nutrition fields (calories, sugar, sodium, fat, saturated fat, unsaturated fat, trans fat, carbohydrates, fiber, protein, cholesterol).
* Updated recipe endpoint: added support for nested `meta` payload structure (preferred); flat payload remains supported for backward compatibility.
* Updated SEO endpoint: added Open Graph fields (og_title, og_description), Twitter card fields (twitter_title, twitter_description), and canonical URL.
* Added priority-based adapter selection for both SEO and recipe modules.
* Fixed version constant inconsistency (was 1.0.1 internally while header declared 1.0.2).

= 1.0.2 =
* Minor internal correction.

= 1.0.1 =
* Initial release.
* Plugin detection for Rank Math SEO and Tasty Recipes.
* REST API: GET /status, GET /capabilities, POST /seo, POST /recipe.
* Rank Math SEO adapter: title, description, focus keyword, robots.
* Tasty Recipes adapter: full recipe creation with shortcode insertion.
* Minimal admin settings page with bridge status and capabilities overview.

== Upgrade Notice ==

= 1.0.4 =
Fixes WP Recipe Maker adapter to use WPRM's native internal API. Fixes WP Delicious adapter to write to the correct single meta key. Corrects WP Delicious shortcode. Ensures recipe card shortcode is always inserted regardless of featured image.

= 1.0.3 =
Adds support for Yoast SEO, AIOSEO, WP Recipe Maker, and WP Delicious. Expands Tasty Recipes with full nutrition fields. Updates recipe endpoint with nested meta payload support.
