<?php
/**
 * Tasty Recipes adapter for Hicham Global Bridge.
 *
 * Creates a Tasty Recipes recipe entry (CPT: tasty_recipe),
 * populates its meta fields, and inserts the shortcode into
 * the parent post content.
 *
 * @package Hicham GlobalBridge\Modules\Recipes\Adapters
 */

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Create a Tasty Recipe and attach it to a post.
 *
 * Steps:
 * 1. Create a `tasty_recipe` CPT entry via wp_insert_post().
 * 2. Set the featured image via set_post_thumbnail() if provided.
 * 3. Populate recipe meta fields via update_post_meta().
 * 4. Append the [tasty-recipe] shortcode to the parent post content.
 *
 * Meta keys are stored directly on the `tasty_recipe` CPT using the
 * field name as the meta key (e.g., 'description', 'ingredients', 'calories').
 *
 * @param int   $post_id The parent post ID to attach the recipe to.
 * @param array $data    Sanitized recipe data. Expected keys:
 *                       title, featured_media, author_name, description,
 *                       ingredients, instructions, notes, keywords,
 *                       prep_time, cook_time, total_time, yield,
 *                       category, method, cuisine, diet, serving_size,
 *                       calories, sugar, sodium, fat, saturated_fat,
 *                       unsaturated_fat, trans_fat, carbohydrates,
 *                       fiber, protein, cholesterol.
 * @return array|WP_Error Array with 'recipe_id' on success, WP_Error on failure.
 */
function HICHAM_GLOBAL_BRIDGE_recipe_tasty_create($post_id, $data)
{

    // Verify the Tasty Recipes CPT is registered.
    if (!post_type_exists('tasty_recipe')) {
        return new WP_Error(
            'HICHAM_GLOBAL_BRIDGE_tasty_not_ready',
            __('Tasty Recipes plugin is not fully loaded. The tasty_recipe post type is not registered.', 'hicham-global-bridge'),
            array('status' => 500)
        );
    }

    // 1. Create the recipe CPT entry.
    $recipe_args = array(
        'post_type'   => 'tasty_recipe',
        'post_title'  => $data['title'],
        'post_status' => 'publish',
        'post_author' => get_current_user_id(),
    );

    $recipe_id = wp_insert_post($recipe_args, true);

    if (is_wp_error($recipe_id)) {
        return new WP_Error(
            'HICHAM_GLOBAL_BRIDGE_recipe_creation_failed',
            __('Failed to create the recipe entry.', 'hicham-global-bridge'),
            array('status' => 500)
        );
    }

    // 2. Featured image.
    if (!empty($data['featured_media'])) {
        set_post_thumbnail($recipe_id, (int) $data['featured_media']);
    }

    // 3. Populate recipe meta fields.
    // Tasty Recipes stores all fields as post meta using the field name as key.
    $meta_fields = array(
        // Core content.
        'description'     => $data['description'],
        'ingredients'     => $data['ingredients'],
        'instructions'    => $data['instructions'],
        'notes'           => $data['notes'],

        // Timing.
        'prep_time'       => $data['prep_time'],
        'cook_time'       => $data['cook_time'],
        'total_time'      => $data['total_time'],

        // Yield / serving.
        'yield'           => $data['yield'],         // Tasty Recipes uses 'yield' for servings.

        // Taxonomy / classification (stored as plain text meta in Tasty Recipes).
        'author_name'     => $data['author_name'],
        'keywords'        => $data['keywords'],
        'category'        => $data['category'],
        'method'          => $data['method'],
        'cuisine'         => $data['cuisine'],
        'diet'            => $data['diet'],

        // Nutrition.
        'serving_size'    => $data['serving_size'],
        'calories'        => $data['calories'],
        'sugar'           => $data['sugar'],
        'sodium'          => $data['sodium'],
        'fat'             => $data['fat'],
        'saturated_fat'   => $data['saturated_fat'],
        'unsaturated_fat' => $data['unsaturated_fat'],
        'trans_fat'       => $data['trans_fat'],
        'carbohydrates'   => $data['carbohydrates'],
        'fiber'           => $data['fiber'],
        'protein'         => $data['protein'],
        'cholesterol'     => $data['cholesterol'],
    );

    foreach ($meta_fields as $key => $value) {
        if ('' !== $value) {
            update_post_meta($recipe_id, $key, $value);
        }
    }

    // 4. Append the shortcode to the parent post content.
    $shortcode    = '[tasty-recipe id="' . $recipe_id . '"]';
    $parent_post  = get_post($post_id);
    $post_content = $parent_post->post_content;

    // Check if the shortcode is already present (prevent duplicates).
    if (strpos($post_content, $shortcode) === false) {
        $updated_content = $post_content . "\n\n" . $shortcode;

        $update_result = wp_update_post(
            array(
                'ID'           => $post_id,
                'post_content' => $updated_content,
            ),
            true
        );

        if (is_wp_error($update_result)) {
            return new WP_Error(
                'HICHAM_GLOBAL_BRIDGE_shortcode_insertion_failed',
                __('Recipe created but failed to insert the shortcode into the post.', 'hicham-global-bridge'),
                array(
                    'status'    => 500,
                    'recipe_id' => $recipe_id,
                )
            );
        }
    }

    return array('recipe_id' => $recipe_id);
}
