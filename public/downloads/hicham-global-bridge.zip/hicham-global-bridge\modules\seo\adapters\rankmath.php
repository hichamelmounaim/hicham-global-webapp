<?php
/**
 * Rank Math SEO adapter for Hicham Global Bridge.
 *
 * Applies SEO metadata to a WordPress post using Rank Math's
 * post meta keys. Rank Math stores all SEO data as standard
 * WordPress post meta with the `rank_math_` prefix.
 *
 * @package Hicham GlobalBridge\Modules\SEO\Adapters
 */

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Apply SEO metadata to a post via Rank Math.
 *
 * Meta keys used:
 * - rank_math_title         — Custom SEO title
 * - rank_math_description   — Meta description
 * - rank_math_focus_keyword — Focus keyword
 * - rank_math_robots        — Robots directives (serialized array)
 *
 * @param int   $post_id The target post ID.
 * @param array $data    Sanitized SEO data with keys: title, description, focus_keyword, robots.
 * @return true|WP_Error True on success, WP_Error on failure.
 */
function HICHAM_GLOBAL_BRIDGE_seo_rankmath_apply($post_id, $data)
{

    $updated_fields = array();

    // SEO Title.
    if (!empty($data['title'])) {
        update_post_meta($post_id, 'rank_math_title', $data['title']);
        $updated_fields[] = 'title';
    }

    // Meta Description.
    if (!empty($data['description'])) {
        update_post_meta($post_id, 'rank_math_description', $data['description']);
        $updated_fields[] = 'description';
    }

    // Focus Keyword.
    if (!empty($data['focus_keyword'])) {
        update_post_meta($post_id, 'rank_math_focus_keyword', $data['focus_keyword']);
        $updated_fields[] = 'focus_keyword';
    }

    // Robots directives.
    if (!empty($data['robots'])) {
        // Rank Math stores robots as a serialized array of directives.
        // Common values: noindex, nofollow, noarchive, noimageindex, nosnippet.
        $robots = array_map('trim', explode(',', $data['robots']));
        $robots = array_filter($robots);
        update_post_meta($post_id, 'rank_math_robots', $robots);
        $updated_fields[] = 'robots';
    }

    if (empty($updated_fields)) {
        return new WP_Error(
            'HICHAM_GLOBAL_BRIDGE_seo_no_update',
            __('No SEO fields were updated.', 'hicham-global-bridge'),
            array('status' => 400)
            );
    }

    return true;
}
