<?php
/**
 * WP Delicious adapter for Hicham Global Bridge.
 *
 * Creates a WP Delicious recipe entry (CPT: recipe), populates its metadata
 * via the single `delicious_recipes_metadata` post meta key, assigns taxonomy
 * terms, and inserts the shortcode into the parent post content.
 *
 * WP Delicious stores all recipe data as a single serialized array under the
 * `delicious_recipes_metadata` meta key using camelCase field names. Writing
 * individual meta keys outside this structure has no effect — WP Delicious
 * does not read them.
 *
 * Taxonomy slugs: recipe-cuisine, recipe-course, recipe-cooking-method.
 * Shortcode: [delicious-recipe id="X"]
 *
 * The shortcode is inserted unconditionally — featured_media is optional and
 * never blocks shortcode insertion.
 *
 * @package Hicham GlobalBridge\Modules\Recipes\Adapters
 */

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Parse newline-separated ingredient text into WP Delicious structured format.
 *
 * Attempts to extract quantity and unit from each ingredient line. Falls back
 * to placing the full line in `ingredient` when parsing fails.
 *
 * @param string $text Newline-separated ingredient lines.
 * @return array WP Delicious ingredient groups structure.
 */
function HICHAM_GLOBAL_BRIDGE_wpdelicious_parse_ingredients($text)
{
    $lines = array_values(array_filter(array_map('trim', explode("\n", $text))));
    $items = array();

    $known_units = array(
        'tsp', 'tbsp', 'cup', 'cups', 'oz', 'lb', 'lbs', 'g', 'kg',
        'ml', 'l', 'liter', 'liters', 'pint', 'quart', 'gallon',
        'clove', 'cloves', 'slice', 'slices', 'piece', 'pieces',
        'handful', 'pinch', 'dash', 'can', 'cans', 'pkg', 'package',
        'teaspoon', 'teaspoons', 'tablespoon', 'tablespoons',
        'ounce', 'ounces', 'pound', 'pounds', 'gram', 'grams',
    );

    foreach ($lines as $line) {
        $quantity   = '';
        $unit       = '';
        $ingredient = $line;

        // Pattern: number (with optional fraction/mixed number), unit word, name.
        $pattern = '/^(\d+(?:\s*\/\s*\d+|\s+\d+\/\d+)?)\s+([a-zA-Z]+\.?)\s+(.+)$/u';

        if (preg_match($pattern, $line, $matches)) {
            $candidate_unit = trim($matches[2]);

            if (in_array(strtolower($candidate_unit), $known_units, true)) {
                $quantity   = trim($matches[1]);
                $unit       = $candidate_unit;
                $ingredient = trim($matches[3]);
            } else {
                // Unrecognized unit word — treat as part of ingredient name.
                $quantity   = trim($matches[1]);
                $ingredient = trim($candidate_unit . ' ' . $matches[3]);
            }
        } elseif (preg_match('/^(\d+(?:\s*\/\s*\d+|\s+\d+\/\d+)?)\s+(.+)$/u', $line, $matches)) {
            // Number only, no unit.
            $quantity   = trim($matches[1]);
            $ingredient = trim($matches[2]);
        }

        $items[] = array(
            'quantity'   => $quantity,
            'unit'       => $unit,
            'ingredient' => $ingredient,
            'notes'      => '',
        );
    }

    return array(
        array(
            'sectionTitle' => '',
            'ingredients'  => $items,
        ),
    );
}

/**
 * Parse newline-separated instruction text into WP Delicious structured format.
 *
 * @param string $text Newline-separated instruction lines.
 * @return array WP Delicious instruction groups structure.
 */
function HICHAM_GLOBAL_BRIDGE_wpdelicious_parse_instructions($text)
{
    $lines = array_values(array_filter(array_map('trim', explode("\n", $text))));
    $items = array();

    foreach ($lines as $line) {
        $items[] = array(
            'instructionTitle' => '',
            'instruction'      => $line,
            'instructionNotes' => '',
            'image'            => '',
            'videoURL'         => '',
        );
    }

    return array(
        array(
            'sectionTitle' => '',
            'instruction'  => $items,
        ),
    );
}

/**
 * Create a WP Delicious recipe and attach it to a post.
 *
 * Steps:
 * 1. Create a `recipe` CPT entry via wp_insert_post().
 * 2. Set the featured image via set_post_thumbnail() if provided.
 * 3. Parse ingredients and instructions into WP Delicious structured arrays.
 * 4. Build and write the single `delicious_recipes_metadata` meta entry.
 * 5. Assign taxonomy terms (cuisine, course, cooking method).
 * 6. Append the [delicious-recipe] shortcode to the parent post content.
 *
 * @param int   $post_id The parent post ID to attach the recipe to.
 * @param array $data    Sanitized recipe data. Expected keys:
 *                       title, featured_media, author_name, description,
 *                       ingredients, instructions, notes, keywords,
 *                       prep_time, cook_time, total_time, yield,
 *                       category, method, cuisine, serving_size,
 *                       calories, sugar, sodium, fat, saturated_fat,
 *                       unsaturated_fat, trans_fat, carbohydrates,
 *                       fiber, protein, cholesterol.
 * @return array|WP_Error Array with 'recipe_id' on success, WP_Error on failure.
 */
function HICHAM_GLOBAL_BRIDGE_recipe_wpdelicious_create($post_id, $data)
{

    // Verify the WP Delicious CPT is registered.
    if (!post_type_exists('recipe')) {
        return new WP_Error(
            'HICHAM_GLOBAL_BRIDGE_wpdelicious_not_ready',
            __('WP Delicious is not fully loaded. The recipe post type is not registered.', 'hicham-global-bridge'),
            array('status' => 500)
        );
    }

    // 1. Create the recipe CPT entry.
    $recipe_args = array(
        'post_type'   => 'recipe',
        'post_title'  => $data['title'],
        'post_status' => 'publish',
        'post_author' => get_current_user_id(),
    );

    $recipe_id = wp_insert_post($recipe_args, true);

    if (is_wp_error($recipe_id)) {
        return new WP_Error(
            'HICHAM_GLOBAL_BRIDGE_recipe_creation_failed',
            __('Failed to create the recipe entry.', 'hicham-global-bridge'),
            array('status' => 500)
        );
    }

    // 2. Featured image.
    if (!empty($data['featured_media'])) {
        set_post_thumbnail($recipe_id, (int) $data['featured_media']);
    }

    // 3. Parse structured data.
    $recipe_ingredients  = !empty($data['ingredients'])
        ? HICHAM_GLOBAL_BRIDGE_wpdelicious_parse_ingredients($data['ingredients'])
        : array();

    $recipe_instructions = !empty($data['instructions'])
        ? HICHAM_GLOBAL_BRIDGE_wpdelicious_parse_instructions($data['instructions'])
        : array();

    // Helper: append unit suffix only when the value is non-empty.
    $with_unit = function ($value, $suffix) {
        return ('' !== $value) ? $value . $suffix : '';
    };

    // 4. Build the single metadata array WP Delicious reads.
    // All keys are camelCase as expected by WP Delicious internals.
    $recipe_meta = array(
        // Core content.
        'recipeDescription'  => $data['description'],
        'recipeKeywords'     => $data['keywords'],
        'recipeNotes'        => $data['notes'],

        // Author.
        'recipeAuthor'       => $data['author_name'],

        // Timing.
        'prepTime'           => $data['prep_time'],
        'prepTimeUnit'       => 'min',
        'cookTime'           => $data['cook_time'],
        'cookTimeUnit'       => 'min',
        'restTime'           => '',
        'restTimeUnit'       => 'min',

        // Temperature (not in payload — left empty).
        'cookingTemp'        => '',
        'cookingTempUnit'    => 'C',

        // Yield / serving.
        'noOfServings'       => $data['yield'],
        'servingSize'        => $data['serving_size'],

        // Ingredients.
        'ingredientTitle'    => 'Ingredients',
        'recipeIngredients'  => $recipe_ingredients,

        // Instructions.
        'instructionsTitle'  => 'Instructions',
        'recipeInstructions' => $recipe_instructions,

        // Nutrition — WP Delicious stores numeric nutrition with unit suffixes.
        'recipeCalories'     => $data['calories'],
        'calories'           => $data['calories'],
        'totalFat'           => $with_unit($data['fat'], 'g'),
        'saturatedFat'       => $with_unit($data['saturated_fat'], 'g'),
        'transFat'           => $with_unit($data['trans_fat'], 'g'),
        'cholesterol'        => $with_unit($data['cholesterol'], 'mg'),
        'sodium'             => $with_unit($data['sodium'], 'mg'),
        'totalCarbohydrate'  => $with_unit($data['carbohydrates'], 'g'),
        'dietaryFiber'       => $with_unit($data['fiber'], 'g'),
        'sugars'             => $with_unit($data['sugar'], 'g'),
        'protein'            => $with_unit($data['protein'], 'g'),

        // Misc fields.
        'bestSeason'         => array(),
        'estimatedCost'      => '',
        'estimatedCostCurr'  => '',
    );

    // Write all recipe data as a single serialized meta entry.
    update_post_meta($recipe_id, 'delicious_recipes_metadata', $recipe_meta);

    // 5. Taxonomy terms (WP Delicious uses standard WordPress taxonomies).
    $taxonomy_map = array(
        'recipe-cuisine'        => $data['cuisine'],
        'recipe-course'         => $data['category'],
        'recipe-cooking-method' => $data['method'],
    );

    foreach ($taxonomy_map as $taxonomy => $value) {
        if (!empty($value)) {
            $term_id = HICHAM_GLOBAL_BRIDGE_ensure_term($taxonomy, $value);
            if ($term_id > 0) {
                wp_set_post_terms($recipe_id, array($term_id), $taxonomy);
            }
        }
    }

    // 6. Append the shortcode to the parent post content.
    // Runs unconditionally — featured_media is optional and never blocks insertion.
    $shortcode    = '[delicious-recipe id="' . $recipe_id . '"]';
    $parent_post  = get_post($post_id);
    $post_content = $parent_post->post_content;

    if (strpos($post_content, $shortcode) === false) {
        $updated_content = $post_content . "\n\n" . $shortcode;

        $update_result = wp_update_post(
            array(
                'ID'           => $post_id,
                'post_content' => $updated_content,
            ),
            true
        );

        if (is_wp_error($update_result)) {
            return new WP_Error(
                'HICHAM_GLOBAL_BRIDGE_shortcode_insertion_failed',
                __('Recipe created but failed to insert the shortcode into the post.', 'hicham-global-bridge'),
                array(
                    'status'    => 500,
                    'recipe_id' => $recipe_id,
                )
            );
        }
    }

    return array('recipe_id' => $recipe_id);
}
