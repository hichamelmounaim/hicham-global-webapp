<?php
/**
 * Yoast SEO adapter for Hicham Global Bridge.
 *
 * Applies SEO metadata to a WordPress post using Yoast SEO's
 * post meta keys. Yoast SEO stores all SEO data as standard
 * WordPress post meta with the `_yoast_wpseo_` prefix.
 *
 * @package Hicham GlobalBridge\Modules\SEO\Adapters
 */

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Apply SEO metadata to a post via Yoast SEO.
 *
 * Meta keys used:
 * - _yoast_wpseo_title                 — Custom SEO title
 * - _yoast_wpseo_metadesc              — Meta description
 * - _yoast_wpseo_focuskw               — Focus keyphrase
 * - _yoast_wpseo_opengraph-title       — Open Graph title
 * - _yoast_wpseo_opengraph-description — Open Graph description
 * - _yoast_wpseo_twitter-title         — Twitter card title
 * - _yoast_wpseo_twitter-description   — Twitter card description
 * - _yoast_wpseo_canonical             — Canonical URL
 * - _yoast_wpseo_meta-robots-noindex   — Robots noindex (1 = noindex, 0 = index)
 * - _yoast_wpseo_meta-robots-nofollow  — Robots nofollow (1 = nofollow, 0 = follow)
 * - _yoast_wpseo_meta-robots-adv       — Advanced robots (noarchive, nosnippet, noimageindex)
 *
 * @param int   $post_id The target post ID.
 * @param array $data    Sanitized SEO data with keys: title, description, focus_keyword,
 *                       robots, og_title, og_description, twitter_title,
 *                       twitter_description, canonical.
 * @return true|WP_Error True on success, WP_Error on failure.
 */
function HICHAM_GLOBAL_BRIDGE_seo_yoast_apply($post_id, $data)
{

    // Guard: ensure Yoast SEO is fully loaded.
    if (!class_exists('WPSEO_Meta')) {
        return new WP_Error(
            'HICHAM_GLOBAL_BRIDGE_yoast_not_ready',
            __('Yoast SEO is not fully loaded.', 'hicham-global-bridge'),
            array('status' => 500)
        );
    }

    $updated_fields = array();

    // SEO Title.
    if (!empty($data['title'])) {
        update_post_meta($post_id, '_yoast_wpseo_title', $data['title']);
        $updated_fields[] = 'title';
    }

    // Meta Description.
    if (!empty($data['description'])) {
        update_post_meta($post_id, '_yoast_wpseo_metadesc', $data['description']);
        $updated_fields[] = 'description';
    }

    // Focus Keyphrase.
    if (!empty($data['focus_keyword'])) {
        update_post_meta($post_id, '_yoast_wpseo_focuskw', $data['focus_keyword']);
        $updated_fields[] = 'focus_keyword';
    }

    // Open Graph Title.
    if (!empty($data['og_title'])) {
        update_post_meta($post_id, '_yoast_wpseo_opengraph-title', $data['og_title']);
        $updated_fields[] = 'og_title';
    }

    // Open Graph Description.
    if (!empty($data['og_description'])) {
        update_post_meta($post_id, '_yoast_wpseo_opengraph-description', $data['og_description']);
        $updated_fields[] = 'og_description';
    }

    // Twitter Card Title.
    if (!empty($data['twitter_title'])) {
        update_post_meta($post_id, '_yoast_wpseo_twitter-title', $data['twitter_title']);
        $updated_fields[] = 'twitter_title';
    }

    // Twitter Card Description.
    if (!empty($data['twitter_description'])) {
        update_post_meta($post_id, '_yoast_wpseo_twitter-description', $data['twitter_description']);
        $updated_fields[] = 'twitter_description';
    }

    // Canonical URL.
    if (!empty($data['canonical'])) {
        update_post_meta($post_id, '_yoast_wpseo_canonical', $data['canonical']);
        $updated_fields[] = 'canonical';
    }

    // Robots directives (parsed from comma-separated string).
    // Yoast stores noindex and nofollow as separate integer meta keys,
    // and advanced directives (noarchive, nosnippet, noimageindex) as a comma-separated string.
    if (!empty($data['robots'])) {
        $directives = array_map('trim', explode(',', strtolower($data['robots'])));
        $directives = array_filter($directives);

        $noindex  = in_array('noindex', $directives, true) ? '1' : '0';
        $nofollow = in_array('nofollow', $directives, true) ? '1' : '0';

        update_post_meta($post_id, '_yoast_wpseo_meta-robots-noindex', $noindex);
        update_post_meta($post_id, '_yoast_wpseo_meta-robots-nofollow', $nofollow);

        $advanced_allowed = array('noarchive', 'nosnippet', 'noimageindex');
        $advanced         = array_values(array_intersect($directives, $advanced_allowed));

        if (!empty($advanced)) {
            update_post_meta($post_id, '_yoast_wpseo_meta-robots-adv', implode(',', $advanced));
        }

        $updated_fields[] = 'robots';
    }

    if (empty($updated_fields)) {
        return new WP_Error(
            'HICHAM_GLOBAL_BRIDGE_yoast_no_update',
            __('No SEO fields were updated.', 'hicham-global-bridge'),
            array('status' => 400)
        );
    }

    return true;
}
