<?php
/**
 * REST API permission callbacks for Hicham Global Bridge.
 *
 * All routes require the requesting user to have the `edit_posts`
 * capability. Authentication is handled by WordPress core
 * (Application Password).
 *
 * @package Hicham GlobalBridge\Core
 */

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Check if the current user has permission to access Hicham Global Bridge endpoints.
 *
 * Requires the `edit_posts` capability, which is available to
 * Administrators and Editors by default.
 *
 * @param WP_REST_Request $request The incoming REST request.
 * @return bool|WP_Error True if authorized, WP_Error otherwise.
 */
function HICHAM_GLOBAL_BRIDGE_check_permission($request)
{
    if (!current_user_can('edit_posts')) {
        return new WP_Error(
            'HICHAM_GLOBAL_BRIDGE_unauthorized',
            __('You do not have permission to access this endpoint.', 'hicham-global-bridge'),
            array('status' => 403)
            );
    }

    return true;
}
