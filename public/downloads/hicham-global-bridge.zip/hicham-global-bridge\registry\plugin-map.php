<?php
/**
 * Plugin map registry for Hicham Global Bridge.
 *
 * Defines all WordPress plugins that Hicham Global Bridge can interface with.
 * Each entry maps a slug to metadata used for detection and routing.
 *
 * To add support for a new plugin, add a new entry to this array.
 *
 * @package Hicham GlobalBridge\Registry
 */

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

return array(

    // --- SEO plugins ---

    'rankmath' => array(
        'name'   => 'Rank Math SEO',
        'file'   => 'seo-by-rank-math/rank-math.php',
        'module' => 'seo',
    ),
    'yoast' => array(
        'name'   => 'Yoast SEO',
        'file'   => 'wordpress-seo/wp-seo.php',
        'module' => 'seo',
    ),
    'aioseo' => array(
        'name'   => 'All in One SEO',
        'file'   => 'all-in-one-seo-pack/all_in_one_seo_pack.php',
        'module' => 'seo',
    ),

    // --- Recipe plugins ---

    'tasty-recipes' => array(
        'name'   => 'Tasty Recipes',
        'file'   => 'tasty-recipes/tasty-recipes.php',
        'module' => 'recipes',
    ),
    'wprm' => array(
        'name'   => 'WP Recipe Maker',
        'file'   => 'wp-recipe-maker/wp-recipe-maker.php',
        'module' => 'recipes',
    ),
    'wpdelicious' => array(
        'name'   => 'WP Delicious',
        'file'   => 'delicious-recipes/delicious-recipes.php',
        'module' => 'recipes',
    ),
);
