<?php
/**
 * Plugin detection system for Hicham Global Bridge.
 *
 * Detects which supported third-party plugins are currently
 * installed and active on the WordPress site by checking
 * against the plugin registry.
 *
 * @package Hicham GlobalBridge\Core
 */

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Detect all supported plugins and return their status.
 *
 * Loads the plugin map from the registry and checks each entry
 * using WordPress `is_plugin_active()`.
 *
 * @return array Associative array of plugin slugs with detection details.
 *               Each entry contains: name, file, module, active (bool).
 */
function HICHAM_GLOBAL_BRIDGE_detect_plugins()
{

    // Ensure is_plugin_active() is available (not loaded on frontend by default).
    if (!function_exists('is_plugin_active')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    $plugin_map = HICHAM_GLOBAL_BRIDGE_get_plugin_map();
    $detected = array();

    foreach ($plugin_map as $slug => $info) {
        $detected[$slug] = array(
            'name' => $info['name'],
            'file' => $info['file'],
            'module' => $info['module'],
            'active' => is_plugin_active($info['file']),
        );
    }

    return $detected;
}

/**
 * Get only the active supported plugins.
 *
 * @return array Filtered array containing only active plugins.
 */
function HICHAM_GLOBAL_BRIDGE_get_active_plugins()
{
    $all_plugins = HICHAM_GLOBAL_BRIDGE_detect_plugins();

    return array_filter(
        $all_plugins,
        function ($plugin) {
        return $plugin['active'];
    }
    );
}

/**
 * Check if a specific supported plugin is active.
 *
 * @param string $slug The plugin slug from the registry (e.g., 'rankmath').
 * @return bool True if the plugin is active.
 */
function HICHAM_GLOBAL_BRIDGE_is_plugin_active($slug)
{
    $plugins = HICHAM_GLOBAL_BRIDGE_detect_plugins();

    return isset($plugins[$slug]) && $plugins[$slug]['active'];
}

/**
 * Load and return the plugin map from the registry.
 *
 * @return array The plugin map array.
 */
function HICHAM_GLOBAL_BRIDGE_get_plugin_map()
{
    return require HICHAM_GLOBAL_BRIDGE_PATH . 'registry/plugin-map.php';
}
