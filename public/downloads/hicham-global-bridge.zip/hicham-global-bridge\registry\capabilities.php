<?php
/**
 * Capabilities registry for Hicham Global Bridge.
 *
 * Defines the capabilities (features) available per module,
 * along with which adapters provide them and which fields
 * each module supports.
 *
 * @package Hicham GlobalBridge\Registry
 */

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

return array(
    'seo' => array(
        'adapters' => array('rankmath', 'yoast', 'aioseo'),
        'fields'   => array(
            'title',
            'description',
            'focus_keyword',
            'robots',
            'og_title',
            'og_description',
            'twitter_title',
            'twitter_description',
            'canonical',
        ),
    ),
    'recipes' => array(
        'adapters' => array('tasty-recipes', 'wprm', 'wpdelicious'),
        'fields'   => array(
            'title',
            'featured_media',
            'author_name',
            'description',
            'ingredients',
            'instructions',
            'notes',
            'keywords',
            'prep_time',
            'cook_time',
            'total_time',
            'yield',
            'category',
            'method',
            'cuisine',
            'diet',
            'serving_size',
            'calories',
            'sugar',
            'sodium',
            'fat',
            'saturated_fat',
            'unsaturated_fat',
            'trans_fat',
            'carbohydrates',
            'fiber',
            'protein',
            'cholesterol',
        ),
    ),
);
