<?php
/**
 * Minimal admin settings page for Hicham Global Bridge.
 *
 * Displays bridge status, detected plugins, and available capabilities.
 * Uses native WordPress admin styles — no custom CSS in V1.
 *
 * @package Hicham GlobalBridge\Admin
 */

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register the admin menu page.
 *
 * @return void
 */
function HICHAM_GLOBAL_BRIDGE_admin_menu()
{
    add_menu_page(
        __('Hicham Global Bridge', 'hicham-global-bridge'), // Page title.
        __('Hicham Global Bridge', 'hicham-global-bridge'), // Menu title.
        'manage_options', // Capability required.
        'hicham-global-bridge', // Menu slug.
        'HICHAM_GLOBAL_BRIDGE_render_settings_page', // Callback function.
        'dashicons-rest-api', // Dashicon.
        80 // Position.
    );
}
add_action('admin_menu', 'HICHAM_GLOBAL_BRIDGE_admin_menu');

/**
 * Render the settings page HTML.
 *
 * @return void
 */
function HICHAM_GLOBAL_BRIDGE_render_settings_page()
{

    // Get detection data.
    $detected_plugins = HICHAM_GLOBAL_BRIDGE_detect_plugins();
    $active_plugins = HICHAM_GLOBAL_BRIDGE_get_active_plugins();
    $capabilities_map = require HICHAM_GLOBAL_BRIDGE_PATH . 'registry/capabilities.php';
    $bridge_status = count($active_plugins) > 0 ? 'active' : 'inactive';

?>
	<div class="wrap">
		<div style="display: flex; align-items: center; gap: 14px; margin-bottom: 10px;">
		<img src="<?php echo esc_url(plugin_dir_url(dirname(__FILE__)) . 'assets/hicham-global-logo.svg'); ?>" alt="Hicham Global" style="height: 36px; width: 36px;">
			<h1 style="margin: 0; padding: 0;"><?php esc_html_e('Hicham Global Bridge Integration', 'hicham-global-bridge'); ?></h1>
		</div>

		<div class="card" style="max-width: 800px;">
			<h2><?php esc_html_e('Bridge Status', 'hicham-global-bridge'); ?></h2>
			<table class="form-table" role="presentation">
				<tbody>
					<tr>
						<th scope="row"><?php esc_html_e('Plugin Version', 'hicham-global-bridge'); ?></th>
						<td><code><?php echo esc_html(HICHAM_GLOBAL_BRIDGE_VERSION); ?></code></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e('Bridge Status', 'hicham-global-bridge'); ?></th>
						<td>
							<?php if ('active' === $bridge_status): ?>
								<span style="color: #00a32a; font-weight: 600;">&#9679; <?php esc_html_e('Active', 'hicham-global-bridge'); ?></span>
								<p class="description">
									<?php
        printf(
            /* translators: %d: number of active adapters */
            esc_html__('%d supported plugin(s) detected and active.', 'hicham-global-bridge'),
            count($active_plugins)
        );
?>
								</p>
							<?php
    else: ?>
								<span style="color: #d63638; font-weight: 600;">&#9679; <?php esc_html_e('Inactive', 'hicham-global-bridge'); ?></span>
								<p class="description">
									<?php esc_html_e('No supported plugins detected. Install at least one supported plugin (Rank Math SEO, Yoast SEO, AIOSEO, Tasty Recipes, WP Recipe Maker, or WP Delicious) to activate the bridge.', 'hicham-global-bridge'); ?>
								</p>
							<?php
    endif; ?>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e('REST Namespace', 'hicham-global-bridge'); ?></th>
						<td><code>/wp-json/hicham_global/v1/</code></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e('WordPress', 'hicham-global-bridge'); ?></th>
						<td><?php echo esc_html(get_bloginfo('version')); ?></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e('PHP', 'hicham-global-bridge'); ?></th>
						<td><?php echo esc_html(phpversion()); ?></td>
					</tr>
				</tbody>
			</table>
		</div>

		<div class="card" style="max-width: 800px; margin-top: 20px;">
			<h2><?php esc_html_e('Detected Plugins', 'hicham-global-bridge'); ?></h2>
			<table class="widefat striped" style="max-width: 100%;">
				<thead>
					<tr>
						<th><?php esc_html_e('Plugin', 'hicham-global-bridge'); ?></th>
						<th><?php esc_html_e('Module', 'hicham-global-bridge'); ?></th>
						<th><?php esc_html_e('Status', 'hicham-global-bridge'); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($detected_plugins as $slug => $plugin): ?>
						<tr>
							<td><?php echo esc_html($plugin['name']); ?></td>
							<td><code><?php echo esc_html($plugin['module']); ?></code></td>
							<td>
								<?php if ($plugin['active']): ?>
									<span style="color: #00a32a;">&#10003; <?php esc_html_e('Active', 'hicham-global-bridge'); ?></span>
								<?php
        else: ?>
									<span style="color: #999;">&#10005; <?php esc_html_e('Not installed', 'hicham-global-bridge'); ?></span>
								<?php
        endif; ?>
							</td>
						</tr>
					<?php
    endforeach; ?>
				</tbody>
			</table>
		</div>

		<div class="card" style="max-width: 800px; margin-top: 20px;">
			<h2><?php esc_html_e('Available Capabilities', 'hicham-global-bridge'); ?></h2>
			<table class="widefat striped" style="max-width: 100%;">
				<thead>
					<tr>
						<th><?php esc_html_e('Module', 'hicham-global-bridge'); ?></th>
						<th><?php esc_html_e('Endpoint', 'hicham-global-bridge'); ?></th>
						<th><?php esc_html_e('Supported Fields', 'hicham-global-bridge'); ?></th>
						<th><?php esc_html_e('Status', 'hicham-global-bridge'); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($capabilities_map as $module => $config):
        $has_active_adapter = false;
        foreach ($config['adapters'] as $adapter_slug) {
            if (isset($detected_plugins[$adapter_slug]) && $detected_plugins[$adapter_slug]['active']) {
                $has_active_adapter = true;
                break;
            }
        }
?>
						<tr>
							<td><strong><?php echo esc_html(ucfirst($module)); ?></strong></td>
							<td><code>POST /hicham_global/v1/<?php echo esc_html($module === 'recipes' ? 'recipe' : $module); ?></code></td>
							<td><?php echo esc_html(implode(', ', $config['fields'])); ?></td>
							<td>
								<?php if ($has_active_adapter): ?>
									<span style="color: #00a32a;">&#10003; <?php esc_html_e('Available', 'hicham-global-bridge'); ?></span>
								<?php
        else: ?>
									<span style="color: #999;">&#10005; <?php esc_html_e('Unavailable', 'hicham-global-bridge'); ?></span>
								<?php
        endif; ?>
							</td>
						</tr>
					<?php
    endforeach; ?>
				</tbody>
			</table>
		</div>

		<div class="card" style="max-width: 800px; margin-top: 20px;">
			<h2><?php esc_html_e('REST API Endpoints', 'hicham-global-bridge'); ?></h2>
			<table class="widefat striped" style="max-width: 100%;">
				<thead>
					<tr>
						<th><?php esc_html_e('Method', 'hicham-global-bridge'); ?></th>
						<th><?php esc_html_e('Endpoint', 'hicham-global-bridge'); ?></th>
						<th><?php esc_html_e('Description', 'hicham-global-bridge'); ?></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><code>GET</code></td>
						<td><code>/wp-json/hicham_global/v1/status</code></td>
						<td><?php esc_html_e('Bridge health status and plugin info', 'hicham-global-bridge'); ?></td>
					</tr>
					<tr>
						<td><code>GET</code></td>
						<td><code>/wp-json/hicham_global/v1/capabilities</code></td>
						<td><?php esc_html_e('Detected plugins and available features', 'hicham-global-bridge'); ?></td>
					</tr>
					<tr>
						<td><code>POST</code></td>
						<td><code>/wp-json/hicham_global/v1/seo</code></td>
						<td><?php esc_html_e('Apply SEO metadata to a post', 'hicham-global-bridge'); ?></td>
					</tr>
					<tr>
						<td><code>POST</code></td>
						<td><code>/wp-json/hicham_global/v1/recipe</code></td>
						<td><?php esc_html_e('Create a recipe card for a post', 'hicham-global-bridge'); ?></td>
					</tr>
				</tbody>
			</table>
			<p class="description" style="margin-top: 10px;">
				<?php esc_html_e('All endpoints require authentication via WordPress Application Password.', 'hicham-global-bridge'); ?>
			</p>
		</div>

	</div>
	<?php
}
