<?php
/**
 * SEO module for Hicham Global Bridge.
 *
 * Handles the POST /hicham_global/v1/seo endpoint by validating the payload
 * and delegating to the appropriate SEO adapter based on detected plugins.
 *
 * Adapter priority order: Rank Math SEO → Yoast SEO → All in One SEO.
 * The first active adapter is used.
 *
 * @package Hicham GlobalBridge\Modules\SEO
 */

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

// Load SEO adapters.
require_once HICHAM_GLOBAL_BRIDGE_PATH . 'modules/seo/adapters/rankmath.php';
require_once HICHAM_GLOBAL_BRIDGE_PATH . 'modules/seo/adapters/yoast.php';
require_once HICHAM_GLOBAL_BRIDGE_PATH . 'modules/seo/adapters/aioseo.php';

/**
 * Handle the POST /hicham_global/v1/seo request.
 *
 * Validates the incoming payload, determines the active SEO adapter,
 * and delegates the SEO metadata application.
 *
 * Expected payload:
 * {
 *     "post_id":              123,        (required)
 *     "title":                "...",      (optional)
 *     "description":          "...",      (optional)
 *     "focus_keyword":        "...",      (optional)
 *     "robots":               "noindex,nofollow"  (optional — comma-separated directives)
 *     "og_title":             "...",      (optional)
 *     "og_description":       "...",      (optional)
 *     "twitter_title":        "...",      (optional)
 *     "twitter_description":  "...",      (optional)
 *     "canonical":            "https://..." (optional)
 * }
 *
 * @param WP_REST_Request $request The incoming REST request.
 * @return WP_REST_Response|WP_Error
 */
function HICHAM_GLOBAL_BRIDGE_handle_seo($request)
{

    $params  = $request->get_json_params();
    $post_id = isset($params['post_id']) ? HICHAM_GLOBAL_BRIDGE_sanitize_int($params['post_id']) : 0;

    // Validate post exists.
    $post = HICHAM_GLOBAL_BRIDGE_get_post_or_error($post_id);
    if (is_wp_error($post)) {
        return $post;
    }

    // Ensure at least one SEO field is provided.
    $seo_fields = array(
        'title',
        'description',
        'focus_keyword',
        'robots',
        'og_title',
        'og_description',
        'twitter_title',
        'twitter_description',
        'canonical',
    );

    $has_field = false;
    foreach ($seo_fields as $field) {
        if (!empty($params[$field])) {
            $has_field = true;
            break;
        }
    }

    if (!$has_field) {
        return HICHAM_GLOBAL_BRIDGE_error_response(
            'HICHAM_GLOBAL_BRIDGE_no_seo_data',
            __('No SEO data provided. At least one SEO field is required.', 'hicham-global-bridge'),
            400
        );
    }

    // Sanitize all SEO fields.
    $data = array(
        'title'               => isset($params['title']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($params['title']) : '',
        'description'         => isset($params['description']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($params['description']) : '',
        'focus_keyword'       => isset($params['focus_keyword']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($params['focus_keyword']) : '',
        'robots'              => isset($params['robots']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($params['robots']) : '',
        'og_title'            => isset($params['og_title']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($params['og_title']) : '',
        'og_description'      => isset($params['og_description']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($params['og_description']) : '',
        'twitter_title'       => isset($params['twitter_title']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($params['twitter_title']) : '',
        'twitter_description' => isset($params['twitter_description']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($params['twitter_description']) : '',
        'canonical'           => isset($params['canonical']) ? esc_url_raw(wp_unslash($params['canonical'])) : '',
    );

    // Determine which SEO adapter to use (priority: rankmath → yoast → aioseo).
    $adapter_priority = array('rankmath', 'yoast', 'aioseo');
    $active_adapter   = '';

    foreach ($adapter_priority as $slug) {
        if (HICHAM_GLOBAL_BRIDGE_is_plugin_active($slug)) {
            $active_adapter = $slug;
            break;
        }
    }

    if ('' === $active_adapter) {
        return HICHAM_GLOBAL_BRIDGE_error_response(
            'HICHAM_GLOBAL_BRIDGE_no_seo_adapter',
            __('No supported SEO plugin is active on this site.', 'hicham-global-bridge'),
            422
        );
    }

    switch ($active_adapter) {
        case 'rankmath':
            $result = HICHAM_GLOBAL_BRIDGE_seo_rankmath_apply($post_id, $data);
            break;
        case 'yoast':
            $result = HICHAM_GLOBAL_BRIDGE_seo_yoast_apply($post_id, $data);
            break;
        case 'aioseo':
            $result = HICHAM_GLOBAL_BRIDGE_seo_aioseo_apply($post_id, $data);
            break;
        default:
            return HICHAM_GLOBAL_BRIDGE_error_response(
                'HICHAM_GLOBAL_BRIDGE_no_seo_adapter',
                __('No supported SEO plugin is active on this site.', 'hicham-global-bridge'),
                422
            );
    }

    if (is_wp_error($result)) {
        return $result;
    }

    return new WP_REST_Response(
        HICHAM_GLOBAL_BRIDGE_success_response(
            __('SEO metadata applied successfully.', 'hicham-global-bridge'),
            array(
                'post_id' => $post_id,
                'adapter' => $active_adapter,
                'fields'  => array_keys(array_filter($data)),
            )
        ),
        200
    );
}
