<?php
/**
 * Recipe module for Hicham Global Bridge.
 *
 * Handles the POST /hicham_global/v1/recipe endpoint by validating the payload
 * and delegating to the appropriate recipe adapter based on detected plugins.
 *
 * Adapter priority order: Tasty Recipes → WP Recipe Maker → WP Delicious.
 * The first active adapter is used.
 *
 * Payload format — nested (preferred):
 * {
 *     "post_id":        123,              (required)
 *     "title":          "Recipe Title",   (required — top-level)
 *     "featured_media": 456,              (optional — top-level, attachment ID)
 *     "meta": {
 *         "author_name":     "...",       (optional)
 *         "description":     "...",       (optional)
 *         "ingredients":     "...",       (required — newline-separated)
 *         "instructions":    "...",       (required — newline-separated)
 *         "notes":           "...",       (optional)
 *         "keywords":        "...",       (optional)
 *         "prep_time":       "15",        (optional — minutes)
 *         "cook_time":       "30",        (optional — minutes)
 *         "total_time":      "45",        (optional — minutes)
 *         "yield":           "4 servings",(optional)
 *         "category":        "...",       (optional)
 *         "method":          "...",       (optional)
 *         "cuisine":         "...",       (optional)
 *         "diet":            "...",       (optional)
 *         "serving_size":    "...",       (optional)
 *         "calories":        "350",       (optional)
 *         "sugar":           "...",       (optional)
 *         "sodium":          "...",       (optional)
 *         "fat":             "...",       (optional)
 *         "saturated_fat":   "...",       (optional)
 *         "unsaturated_fat": "...",       (optional)
 *         "trans_fat":       "...",       (optional)
 *         "carbohydrates":   "...",       (optional)
 *         "fiber":           "...",       (optional)
 *         "protein":         "...",       (optional)
 *         "cholesterol":     "..."        (optional)
 *     }
 * }
 *
 * Backward-compatible flat format also accepted (all fields at top level).
 *
 * @package Hicham GlobalBridge\Modules\Recipes
 */

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

// Load recipe adapters.
require_once HICHAM_GLOBAL_BRIDGE_PATH . 'modules/recipes/adapters/tasty.php';
require_once HICHAM_GLOBAL_BRIDGE_PATH . 'modules/recipes/adapters/wprm.php';
require_once HICHAM_GLOBAL_BRIDGE_PATH . 'modules/recipes/adapters/wpdelicious.php';

/**
 * Handle the POST /hicham_global/v1/recipe request.
 *
 * Validates the incoming payload, normalizes flat vs. nested meta structure,
 * determines the active recipe adapter, and delegates recipe creation.
 *
 * @param WP_REST_Request $request The incoming REST request.
 * @return WP_REST_Response|WP_Error
 */
function HICHAM_GLOBAL_BRIDGE_handle_recipe($request)
{

    $params  = $request->get_json_params();
    $post_id = isset($params['post_id']) ? HICHAM_GLOBAL_BRIDGE_sanitize_int($params['post_id']) : 0;

    // Validate post exists.
    $post = HICHAM_GLOBAL_BRIDGE_get_post_or_error($post_id);
    if (is_wp_error($post)) {
        return $post;
    }

    // Normalize payload: if a `meta` key is present and is an array, read recipe
    // fields from it; otherwise fall back to reading fields from the top level
    // (backward-compatible flat format).
    $meta_params = (isset($params['meta']) && is_array($params['meta']))
        ? $params['meta']
        : $params;

    // Validate required fields.
    if (empty($params['title'])) {
        return HICHAM_GLOBAL_BRIDGE_error_response(
            'HICHAM_GLOBAL_BRIDGE_missing_recipe_title',
            __('Recipe title is required.', 'hicham-global-bridge'),
            400
        );
    }

    if (empty($meta_params['ingredients'])) {
        return HICHAM_GLOBAL_BRIDGE_error_response(
            'HICHAM_GLOBAL_BRIDGE_missing_ingredients',
            __('Recipe ingredients are required.', 'hicham-global-bridge'),
            400
        );
    }

    if (empty($meta_params['instructions'])) {
        return HICHAM_GLOBAL_BRIDGE_error_response(
            'HICHAM_GLOBAL_BRIDGE_missing_instructions',
            __('Recipe instructions are required.', 'hicham-global-bridge'),
            400
        );
    }

    // Sanitize and normalize all recipe fields into a single flat array.
    // `title` and `featured_media` always come from the top level.
    // All other fields come from `meta_params` (either nested or flat).
    $data = array(
        // Top-level fields.
        'title'           => HICHAM_GLOBAL_BRIDGE_sanitize_string($params['title']),
        'featured_media'  => isset($params['featured_media']) ? HICHAM_GLOBAL_BRIDGE_sanitize_int($params['featured_media']) : 0,

        // Recipe content fields.
        'author_name'     => isset($meta_params['author_name']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['author_name']) : '',
        'description'     => isset($meta_params['description']) ? HICHAM_GLOBAL_BRIDGE_sanitize_textarea($meta_params['description']) : '',
        'ingredients'     => HICHAM_GLOBAL_BRIDGE_sanitize_textarea($meta_params['ingredients']),
        'instructions'    => HICHAM_GLOBAL_BRIDGE_sanitize_textarea($meta_params['instructions']),
        'notes'           => isset($meta_params['notes']) ? HICHAM_GLOBAL_BRIDGE_sanitize_textarea($meta_params['notes']) : '',
        'keywords'        => isset($meta_params['keywords']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['keywords']) : '',

        // Timing.
        'prep_time'       => isset($meta_params['prep_time']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['prep_time']) : '',
        'cook_time'       => isset($meta_params['cook_time']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['cook_time']) : '',
        'total_time'      => isset($meta_params['total_time']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['total_time']) : '',

        // Yield / serving.
        'yield'           => isset($meta_params['yield']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['yield']) : '',

        // Classification.
        'category'        => isset($meta_params['category']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['category']) : '',
        'method'          => isset($meta_params['method']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['method']) : '',
        'cuisine'         => isset($meta_params['cuisine']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['cuisine']) : '',
        'diet'            => isset($meta_params['diet']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['diet']) : '',

        // Nutrition.
        'serving_size'    => isset($meta_params['serving_size']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['serving_size']) : '',
        'calories'        => isset($meta_params['calories']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['calories']) : '',
        'sugar'           => isset($meta_params['sugar']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['sugar']) : '',
        'sodium'          => isset($meta_params['sodium']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['sodium']) : '',
        'fat'             => isset($meta_params['fat']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['fat']) : '',
        'saturated_fat'   => isset($meta_params['saturated_fat']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['saturated_fat']) : '',
        'unsaturated_fat' => isset($meta_params['unsaturated_fat']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['unsaturated_fat']) : '',
        'trans_fat'       => isset($meta_params['trans_fat']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['trans_fat']) : '',
        'carbohydrates'   => isset($meta_params['carbohydrates']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['carbohydrates']) : '',
        'fiber'           => isset($meta_params['fiber']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['fiber']) : '',
        'protein'         => isset($meta_params['protein']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['protein']) : '',
        'cholesterol'     => isset($meta_params['cholesterol']) ? HICHAM_GLOBAL_BRIDGE_sanitize_string($meta_params['cholesterol']) : '',
    );

    // Determine which recipe adapter to use (priority: tasty-recipes → wprm → wpdelicious).
    $adapter_priority = array('tasty-recipes', 'wprm', 'wpdelicious');
    $active_adapter   = '';

    foreach ($adapter_priority as $slug) {
        if (HICHAM_GLOBAL_BRIDGE_is_plugin_active($slug)) {
            $active_adapter = $slug;
            break;
        }
    }

    if ('' === $active_adapter) {
        return HICHAM_GLOBAL_BRIDGE_error_response(
            'HICHAM_GLOBAL_BRIDGE_no_recipe_adapter',
            __('No supported recipe plugin is active on this site.', 'hicham-global-bridge'),
            422
        );
    }

    switch ($active_adapter) {
        case 'tasty-recipes':
            $result = HICHAM_GLOBAL_BRIDGE_recipe_tasty_create($post_id, $data);
            break;
        case 'wprm':
            $result = HICHAM_GLOBAL_BRIDGE_recipe_wprm_create($post_id, $data);
            break;
        case 'wpdelicious':
            $result = HICHAM_GLOBAL_BRIDGE_recipe_wpdelicious_create($post_id, $data);
            break;
        default:
            return HICHAM_GLOBAL_BRIDGE_error_response(
                'HICHAM_GLOBAL_BRIDGE_no_recipe_adapter',
                __('No supported recipe plugin is active on this site.', 'hicham-global-bridge'),
                422
            );
    }

    if (is_wp_error($result)) {
        return $result;
    }

    return new WP_REST_Response(
        HICHAM_GLOBAL_BRIDGE_success_response(
            __('Recipe created and inserted successfully.', 'hicham-global-bridge'),
            array(
                'post_id'   => $post_id,
                'recipe_id' => $result['recipe_id'],
                'adapter'   => $active_adapter,
            )
        ),
        201
    );
}
