<?php
/**
 * WP Recipe Maker adapter for Hicham Global Bridge.
 *
 * Creates a WP Recipe Maker recipe entry (CPT: wprm_recipe),
 * populates its fields using WPRM's native internal API when available,
 * and inserts the shortcode into the parent post content.
 *
 * Primary path: uses WPRM_Recipe_Sanitizer and WPRM_Recipe_Saver to write
 * recipe data through WPRM's own engine, ensuring correct internal cache
 * state and full compatibility with WPRM's rendering pipeline.
 *
 * Fallback path: if WPRM's internal classes are not available (older plugin
 * versions), falls back to writing post meta directly.
 *
 * The shortcode is inserted unconditionally — featured_media is optional and
 * never blocks shortcode insertion.
 *
 * @package Hicham GlobalBridge\Modules\Recipes\Adapters
 */

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Parse a single ingredient line into amount, unit, and name components.
 *
 * Attempts to extract a leading numeric quantity (including fractions like 1/2
 * and mixed numbers like 1 1/2) and an optional recognized unit word from the
 * start of the string. Falls back to placing the entire string in `name` when
 * parsing fails or the unit is not recognized.
 *
 * @param string $line A single ingredient line, e.g. "2 cups flour".
 * @return array { amount: string, unit: string, name: string }
 */
function HICHAM_GLOBAL_BRIDGE_wprm_parse_ingredient($line)
{
    $line = trim($line);

    if (empty($line)) {
        return array('amount' => '', 'unit' => '', 'name' => $line);
    }

    $known_units = array(
        'tsp', 'tbsp', 'cup', 'cups', 'oz', 'lb', 'lbs', 'g', 'kg',
        'ml', 'l', 'liter', 'liters', 'pint', 'quart', 'gallon',
        'clove', 'cloves', 'slice', 'slices', 'piece', 'pieces',
        'handful', 'pinch', 'dash', 'can', 'cans', 'package', 'pkg',
        'teaspoon', 'teaspoons', 'tablespoon', 'tablespoons',
        'ounce', 'ounces', 'pound', 'pounds', 'gram', 'grams',
        'kilogram', 'kilograms', 'milliliter', 'milliliters',
    );

    // Pattern: number (with optional fraction/mixed number), optional unit word, then name.
    // Matches: "2 cups flour", "1 1/2 tsp salt", "1/4 cup sugar".
    $pattern = '/^(\d+(?:\s+\d+\/\d+|\s*\/\s*\d+)?)\s+([a-zA-Z]+\.?)\s+(.+)$/u';

    if (preg_match($pattern, $line, $matches)) {
        $amount         = trim($matches[1]);
        $candidate_unit = trim($matches[2]);
        $name           = trim($matches[3]);

        if (in_array(strtolower($candidate_unit), $known_units, true)) {
            return array('amount' => $amount, 'unit' => $candidate_unit, 'name' => $name);
        }

        // Unit word not recognized — treat it as part of the ingredient name.
        return array('amount' => $amount, 'unit' => '', 'name' => trim($candidate_unit . ' ' . $name));
    }

    // Pattern: number only, followed by the ingredient name (no unit).
    // Matches: "2 eggs", "3 tomatoes".
    if (preg_match('/^(\d+(?:\s*\/\s*\d+|\s+\d+\/\d+)?)\s+(.+)$/u', $line, $matches)) {
        return array('amount' => trim($matches[1]), 'unit' => '', 'name' => trim($matches[2]));
    }

    // No parseable number — put everything in name.
    return array('amount' => '', 'unit' => '', 'name' => $line);
}

/**
 * Create a WP Recipe Maker recipe and attach it to a post.
 *
 * Steps (primary path — WPRM native API):
 * 1. Create a `wprm_recipe` CPT entry via wp_insert_post().
 * 2. Build recipe_data in WPRM's native array format.
 * 3. Sanitize via WPRM_Recipe_Sanitizer::sanitize().
 * 4. Save via WPRM_Recipe_Saver::update_recipe() (handles cache invalidation).
 * 5. Log via WPRM_Changelog::log() if available.
 * 6. Append [wprm-recipe] shortcode to the parent post content.
 *
 * Steps (fallback path — legacy WPRM versions without internal classes):
 * 1. Create a `wprm_recipe` CPT entry.
 * 2. Set featured thumbnail.
 * 3. Write individual post meta fields.
 * 4. Append shortcode.
 *
 * @param int   $post_id The parent post ID to attach the recipe to.
 * @param array $data    Sanitized recipe data. Expected keys:
 *                       title, featured_media, author_name, description,
 *                       ingredients, instructions, notes, keywords,
 *                       prep_time, cook_time, total_time, yield,
 *                       category, cuisine, serving_size, calories,
 *                       sugar, sodium, fat, saturated_fat, unsaturated_fat,
 *                       trans_fat, carbohydrates, fiber, protein, cholesterol.
 * @return array|WP_Error Array with 'recipe_id' on success, WP_Error on failure.
 */
function HICHAM_GLOBAL_BRIDGE_recipe_wprm_create($post_id, $data)
{

    // Verify the WP Recipe Maker CPT is registered.
    if (!post_type_exists('wprm_recipe')) {
        return new WP_Error(
            'HICHAM_GLOBAL_BRIDGE_wprm_not_ready',
            __('WP Recipe Maker is not fully loaded. The wprm_recipe post type is not registered.', 'hicham-global-bridge'),
            array('status' => 500)
        );
    }

    // 1. Create the recipe CPT entry.
    $recipe_args = array(
        'post_type'   => 'wprm_recipe',
        'post_title'  => $data['title'],
        'post_status' => 'publish',
        'post_author' => get_current_user_id(),
    );

    $recipe_id = wp_insert_post($recipe_args, true);

    if (is_wp_error($recipe_id)) {
        return new WP_Error(
            'HICHAM_GLOBAL_BRIDGE_recipe_creation_failed',
            __('Failed to create the recipe entry.', 'hicham-global-bridge'),
            array('status' => 500)
        );
    }

    // Determine whether WPRM's native API classes are available.
    $has_native_api = class_exists('WPRM_Recipe_Saver') && class_exists('WPRM_Recipe_Sanitizer');

    if ($has_native_api) {

        // ---- PRIMARY PATH: WPRM native API ----

        // Build ingredients in WPRM's native format.
        $ingredient_items = array();
        if (!empty($data['ingredients'])) {
            $lines = array_values(array_filter(array_map('trim', explode("\n", $data['ingredients']))));
            foreach ($lines as $line) {
                $parsed           = HICHAM_GLOBAL_BRIDGE_wprm_parse_ingredient($line);
                $ingredient_items[] = array(
                    'amount' => $parsed['amount'],
                    'unit'   => $parsed['unit'],
                    'name'   => $parsed['name'],
                    'notes'  => '',
                );
            }
        }

        // Build instructions in WPRM's native format; each step wrapped in <p>.
        $instruction_items = array();
        if (!empty($data['instructions'])) {
            $lines = array_values(array_filter(array_map('trim', explode("\n", $data['instructions']))));
            foreach ($lines as $line) {
                $instruction_items[] = array(
                    'text'  => '<p>' . esc_html($line) . '</p>',
                    'image' => 0,
                );
            }
        }

        // Build tags. WPRM expects taxonomy values as arrays of term name strings.
        $tags = array();
        if (!empty($data['category'])) {
            $tags['course'] = array($data['category']);
        }
        if (!empty($data['cuisine'])) {
            $tags['cuisine'] = array($data['cuisine']);
        }
        if (!empty($data['keywords'])) {
            // Keywords may be comma-separated.
            $kw_list = array_values(array_filter(array_map('trim', explode(',', $data['keywords']))));
            if (!empty($kw_list)) {
                $tags['keyword'] = $kw_list;
            }
        }

        // Build nutrition array with integer values (serving_size stays as string).
        $nutrition_map = array(
            'calories'            => $data['calories'],
            'carbohydrates'       => $data['carbohydrates'],
            'protein'             => $data['protein'],
            'fat'                 => $data['fat'],
            'saturated_fat'       => $data['saturated_fat'],
            'polyunsaturated_fat' => $data['unsaturated_fat'],
            'trans_fat'           => $data['trans_fat'],
            'cholesterol'         => $data['cholesterol'],
            'sodium'              => $data['sodium'],
            'fiber'               => $data['fiber'],
            'sugar'               => $data['sugar'],
            'serving_size'        => $data['serving_size'],
        );

        $nutrition = array();
        foreach ($nutrition_map as $key => $value) {
            if ('' !== $value) {
                $nutrition[$key] = ('serving_size' === $key) ? (string) $value : (int) $value;
            }
        }

        // Assemble the full recipe_data array in WPRM's native format.
        $recipe_data = array(
            'type'           => 'food',
            'name'           => $data['title'],
            'summary'        => $data['description'],
            'author_display' => !empty($data['author_name']) ? 'custom' : 'post_author',
            'author_name'    => $data['author_name'],
            'servings'       => $data['yield'],
            'servings_unit'  => 'servings',
            'prep_time'      => $data['prep_time'],
            'cook_time'      => $data['cook_time'],
            'total_time'     => $data['total_time'],
            'image_id'       => (int) $data['featured_media'],
            'tags'           => $tags,
            'ingredients'    => array(
                array(
                    'name'        => '',
                    'ingredients' => $ingredient_items,
                ),
            ),
            'instructions'   => array(
                array(
                    'name'         => '',
                    'instructions' => $instruction_items,
                ),
            ),
            'notes'          => $data['notes'],
            'nutrition'      => $nutrition,
        );

        // Sanitize via WPRM's own sanitizer.
        $recipe_data = WPRM_Recipe_Sanitizer::sanitize($recipe_data);

        // Save via WPRM's own saver — handles internal cache invalidation.
        WPRM_Recipe_Saver::update_recipe($recipe_id, $recipe_data);

        // Log the creation event if WPRM's changelog class is available.
        if (class_exists('WPRM_Changelog')) {
            WPRM_Changelog::log('recipe_created', $recipe_id);
        }
    } else {

        // ---- FALLBACK PATH: direct post meta (legacy WPRM versions) ----

        // Featured image.
        if (!empty($data['featured_media'])) {
            set_post_thumbnail($recipe_id, (int) $data['featured_media']);
        }

        // Basic meta fields.
        $basic_meta = array(
            'wprm_recipe_summary'    => $data['description'],
            'wprm_recipe_notes'      => $data['notes'],
            'wprm_recipe_servings'   => $data['yield'],
            'wprm_recipe_prep_time'  => $data['prep_time'],
            'wprm_recipe_cook_time'  => $data['cook_time'],
            'wprm_recipe_total_time' => $data['total_time'],
        );

        foreach ($basic_meta as $key => $value) {
            if ('' !== $value) {
                update_post_meta($recipe_id, $key, $value);
            }
        }

        // Author name.
        if (!empty($data['author_name'])) {
            update_post_meta($recipe_id, 'wprm_recipe_author_display', 'custom');
            update_post_meta($recipe_id, 'wprm_recipe_author_name', $data['author_name']);
        }

        // Ingredients — parsed from newline-separated text.
        if (!empty($data['ingredients'])) {
            $lines       = array_values(array_filter(array_map('trim', explode("\n", $data['ingredients']))));
            $ingredients = array();

            foreach ($lines as $i => $line) {
                $parsed        = HICHAM_GLOBAL_BRIDGE_wprm_parse_ingredient($line);
                $ingredients[] = array(
                    'uid'         => $i,
                    'amount'      => $parsed['amount'],
                    'unit'        => $parsed['unit'],
                    'name'        => $parsed['name'],
                    'notes'       => '',
                    'unit_system' => 'metric',
                );
            }

            $ingredient_groups = array(
                array(
                    'uid'         => 0,
                    'name'        => '',
                    'ingredients' => $ingredients,
                ),
            );

            update_post_meta($recipe_id, 'wprm_recipe_ingredients', $ingredient_groups);
        }

        // Instructions — parsed from newline-separated text; steps wrapped in <p>.
        if (!empty($data['instructions'])) {
            $lines             = array_values(array_filter(array_map('trim', explode("\n", $data['instructions']))));
            $instructions_list = array();

            foreach ($lines as $i => $line) {
                $instructions_list[] = array(
                    'uid'         => $i,
                    'text'        => '<p>' . esc_html($line) . '</p>',
                    'image'       => 0,
                    'ingredients' => array(),
                );
            }

            $instruction_groups = array(
                array(
                    'uid'          => 0,
                    'name'         => '',
                    'instructions' => $instructions_list,
                ),
            );

            update_post_meta($recipe_id, 'wprm_recipe_instructions', $instruction_groups);
        }

        // Nutrition data — stored as a single serialized array.
        $nutrition = array(
            'serving_size'        => $data['serving_size'],
            'calories'            => $data['calories'],
            'carbs'               => $data['carbohydrates'],
            'protein'             => $data['protein'],
            'fat'                 => $data['fat'],
            'saturated_fat'       => $data['saturated_fat'],
            'polyunsaturated_fat' => $data['unsaturated_fat'],
            'trans_fat'           => $data['trans_fat'],
            'cholesterol'         => $data['cholesterol'],
            'sodium'              => $data['sodium'],
            'fiber'               => $data['fiber'],
            'sugar'               => $data['sugar'],
        );

        $nutrition = array_filter(
            $nutrition,
            function ($v) {
                return '' !== $v;
            }
        );

        if (!empty($nutrition)) {
            update_post_meta($recipe_id, 'wprm_recipe_nutrition', $nutrition);
        }

        // Taxonomy terms.
        $taxonomy_map = array(
            'wprm_cuisine' => $data['cuisine'],
            'wprm_course'  => $data['category'],
            'wprm_keyword' => $data['keywords'],
        );

        foreach ($taxonomy_map as $taxonomy => $value) {
            if (!empty($value)) {
                $term_id = HICHAM_GLOBAL_BRIDGE_ensure_term($taxonomy, $value);
                if ($term_id > 0) {
                    wp_set_post_terms($recipe_id, array($term_id), $taxonomy);
                }
            }
        }
    }

    // Append the shortcode to the parent post content.
    // Runs unconditionally — featured_media is optional and never blocks insertion.
    $shortcode    = '[wprm-recipe id="' . $recipe_id . '"]';
    $parent_post  = get_post($post_id);
    $post_content = $parent_post->post_content;

    if (strpos($post_content, $shortcode) === false) {
        $updated_content = $post_content . "\n\n" . $shortcode;

        $update_result = wp_update_post(
            array(
                'ID'           => $post_id,
                'post_content' => $updated_content,
            ),
            true
        );

        if (is_wp_error($update_result)) {
            return new WP_Error(
                'HICHAM_GLOBAL_BRIDGE_shortcode_insertion_failed',
                __('Recipe created but failed to insert the shortcode into the post.', 'hicham-global-bridge'),
                array(
                    'status'    => 500,
                    'recipe_id' => $recipe_id,
                )
            );
        }
    }

    return array('recipe_id' => $recipe_id);
}
