<?php
/**
 * All in One SEO (AIOSEO) adapter for Hicham Global Bridge.
 *
 * Applies SEO metadata to a WordPress post using AIOSEO's
 * post meta keys. AIOSEO v4 stores metadata as standard
 * WordPress post meta with the `_aioseo_` prefix in addition
 * to its custom database table.
 *
 * @package Hicham GlobalBridge\Modules\SEO\Adapters
 */

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Apply SEO metadata to a post via All in One SEO (AIOSEO).
 *
 * Meta keys used:
 * - _aioseo_title              — Custom SEO title
 * - _aioseo_description        — Meta description
 * - _aioseo_keywords           — Focus keywords
 * - _aioseo_og_title           — Open Graph title
 * - _aioseo_og_description     — Open Graph description
 * - _aioseo_twitter_title      — Twitter card title
 * - _aioseo_twitter_description — Twitter card description
 * - _aioseo_canonical_url      — Canonical URL
 * - _aioseo_noindex            — Robots noindex ('true' / 'false')
 * - _aioseo_nofollow           — Robots nofollow ('true' / 'false')
 *
 * @param int   $post_id The target post ID.
 * @param array $data    Sanitized SEO data with keys: title, description, focus_keyword,
 *                       robots, og_title, og_description, twitter_title,
 *                       twitter_description, canonical.
 * @return true|WP_Error True on success, WP_Error on failure.
 */
function HICHAM_GLOBAL_BRIDGE_seo_aioseo_apply($post_id, $data)
{

    // Guard: ensure AIOSEO is fully loaded (supports both v4 and legacy v3).
    if (!class_exists('AIOSEO\Plugin\AIOSEO') && !class_exists('All_in_One_SEO_Pack')) {
        return new WP_Error(
            'HICHAM_GLOBAL_BRIDGE_aioseo_not_ready',
            __('All in One SEO is not fully loaded.', 'hicham-global-bridge'),
            array('status' => 500)
        );
    }

    $updated_fields = array();

    // SEO Title.
    if (!empty($data['title'])) {
        update_post_meta($post_id, '_aioseo_title', $data['title']);
        $updated_fields[] = 'title';
    }

    // Meta Description.
    if (!empty($data['description'])) {
        update_post_meta($post_id, '_aioseo_description', $data['description']);
        $updated_fields[] = 'description';
    }

    // Focus Keywords.
    if (!empty($data['focus_keyword'])) {
        update_post_meta($post_id, '_aioseo_keywords', $data['focus_keyword']);
        $updated_fields[] = 'focus_keyword';
    }

    // Open Graph Title.
    if (!empty($data['og_title'])) {
        update_post_meta($post_id, '_aioseo_og_title', $data['og_title']);
        $updated_fields[] = 'og_title';
    }

    // Open Graph Description.
    if (!empty($data['og_description'])) {
        update_post_meta($post_id, '_aioseo_og_description', $data['og_description']);
        $updated_fields[] = 'og_description';
    }

    // Twitter Card Title.
    if (!empty($data['twitter_title'])) {
        update_post_meta($post_id, '_aioseo_twitter_title', $data['twitter_title']);
        $updated_fields[] = 'twitter_title';
    }

    // Twitter Card Description.
    if (!empty($data['twitter_description'])) {
        update_post_meta($post_id, '_aioseo_twitter_description', $data['twitter_description']);
        $updated_fields[] = 'twitter_description';
    }

    // Canonical URL.
    if (!empty($data['canonical'])) {
        update_post_meta($post_id, '_aioseo_canonical_url', $data['canonical']);
        $updated_fields[] = 'canonical';
    }

    // Robots directives (parsed from comma-separated string).
    // AIOSEO stores noindex and nofollow as boolean string meta ('true' / 'false').
    if (!empty($data['robots'])) {
        $directives = array_map('trim', explode(',', strtolower($data['robots'])));
        $directives = array_filter($directives);

        $noindex  = in_array('noindex', $directives, true) ? 'true' : 'false';
        $nofollow = in_array('nofollow', $directives, true) ? 'true' : 'false';

        update_post_meta($post_id, '_aioseo_noindex', $noindex);
        update_post_meta($post_id, '_aioseo_nofollow', $nofollow);
        $updated_fields[] = 'robots';
    }

    if (empty($updated_fields)) {
        return new WP_Error(
            'HICHAM_GLOBAL_BRIDGE_aioseo_no_update',
            __('No SEO fields were updated.', 'hicham-global-bridge'),
            array('status' => 400)
        );
    }

    return true;
}
