<?php
/**
 * Shared helper functions for Hicham Global Bridge.
 *
 * Provides sanitization wrappers and common validation utilities
 * used across multiple modules.
 *
 * @package Hicham GlobalBridge\Core
 */

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Sanitize a string value.
 *
 * Wrapper around sanitize_text_field with wp_unslash.
 *
 * @param mixed $value Raw input value.
 * @return string Sanitized string.
 */
function HICHAM_GLOBAL_BRIDGE_sanitize_string($value)
{
    return sanitize_text_field(wp_unslash($value));
}

/**
 * Sanitize an integer value.
 *
 * @param mixed $value Raw input value.
 * @return int Sanitized integer (0 if invalid).
 */
function HICHAM_GLOBAL_BRIDGE_sanitize_int($value)
{
    return absint($value);
}

/**
 * Sanitize a textarea value (preserves line breaks).
 *
 * @param mixed $value Raw input value.
 * @return string Sanitized text with preserved newlines.
 */
function HICHAM_GLOBAL_BRIDGE_sanitize_textarea($value)
{
    return sanitize_textarea_field(wp_unslash($value));
}

/**
 * Validate that a post exists and return the WP_Post object.
 *
 * @param int $post_id The post ID to validate.
 * @return WP_Post|WP_Error The post object or WP_Error if not found.
 */
function HICHAM_GLOBAL_BRIDGE_get_post_or_error($post_id)
{
    $post_id = HICHAM_GLOBAL_BRIDGE_sanitize_int($post_id);

    if ($post_id <= 0) {
        return new WP_Error(
            'HICHAM_GLOBAL_BRIDGE_invalid_post_id',
            __('Invalid post ID provided.', 'hicham-global-bridge'),
            array('status' => 400)
            );
    }

    $post = get_post($post_id);

    if (!$post) {
        return new WP_Error(
            'HICHAM_GLOBAL_BRIDGE_post_not_found',
            __('Post not found.', 'hicham-global-bridge'),
            array('status' => 404)
            );
    }

    return $post;
}

/**
 * Build a standard success response array.
 *
 * @param string $message Success message.
 * @param array  $data    Optional additional data.
 * @return array Response array.
 */
function HICHAM_GLOBAL_BRIDGE_success_response($message, $data = array())
{
    return array_merge(
        array(
        'success' => true,
        'message' => $message,
    ),
        $data
    );
}

/**
 * Build a standard error response.
 *
 * @param string $code    Error code.
 * @param string $message Error message.
 * @param int    $status  HTTP status code.
 * @return WP_Error
 */
function HICHAM_GLOBAL_BRIDGE_error_response($code, $message, $status = 400)
{
    return new WP_Error($code, $message, array('status' => $status));
}

/**
 * Ensure a taxonomy term exists by name, creating it if necessary.
 *
 * Used by recipe adapters to assign taxonomy terms (cuisine, course,
 * keywords) that may not yet exist on the site.
 *
 * @param string $taxonomy The taxonomy slug.
 * @param string $name     The term name (human-readable label).
 * @return int The term ID on success, 0 on failure.
 */
function HICHAM_GLOBAL_BRIDGE_ensure_term($taxonomy, $name)
{
    $name = sanitize_text_field(wp_unslash($name));

    if (empty($name)) {
        return 0;
    }

    $term = get_term_by('name', $name, $taxonomy);

    if ($term instanceof WP_Term) {
        return $term->term_id;
    }

    $result = wp_insert_term($name, $taxonomy);

    if (is_wp_error($result)) {
        return 0;
    }

    return (int) $result['term_id'];
}
