<?php
/**
 * Plugin Name: Hicham Global Bridge Integration
 * Plugin URI:  https://hichamglobal.com/hicham-global-bridge
 * Description: Lightweight bridge plugin that connects the Hicham Global platform to compatible WordPress plugins (Rank Math SEO, Yoast SEO, AIOSEO, Tasty Recipes, WP Recipe Maker, WP Delicious). Exposes unified REST API endpoints for automated SEO metadata and recipe card creation.
 * Version:     1.0.0
 * Author:      Hicham Global
 * Author URI:  https://hichamglobal.com/
 * License:     GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: hicham-global-bridge
 * Domain Path: /languages
 * Requires at least: 5.6
 * Requires PHP: 7.4
 *
 * @package HichamGlobalBridge
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Plugin constants.
define( 'HICHAM_GLOBAL_BRIDGE_VERSION', '1.0.4' );
define( 'HICHAM_GLOBAL_BRIDGE_PATH', plugin_dir_path( __FILE__ ) );
define( 'HICHAM_GLOBAL_BRIDGE_URL', plugin_dir_url( __FILE__ ) );
define( 'HICHAM_GLOBAL_BRIDGE_BASENAME', plugin_basename( __FILE__ ) );

// Load the core loader.
require_once HICHAM_GLOBAL_BRIDGE_PATH . 'core/loader.php';
