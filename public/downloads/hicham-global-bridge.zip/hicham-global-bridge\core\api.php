<?php
/**
 * REST API route registration for Hicham Global Bridge.
 *
 * Registers all REST endpoints under the `hicham_global/v1` namespace.
 * Each route delegates its logic to the appropriate module handler.
 *
 * @package Hicham GlobalBridge\Core
 */

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register all Hicham Global Bridge REST API routes.
 *
 * @return void
 */
function HICHAM_GLOBAL_BRIDGE_register_routes()
{

    $namespace = 'hicham_global/v1';

    // GET /hicham_global/v1/status — Bridge health and plugin info.
    register_rest_route(
        $namespace,
        '/status',
        array(
        'methods' => WP_REST_Server::READABLE,
        'callback' => 'HICHAM_GLOBAL_BRIDGE_handle_status',
        'permission_callback' => 'HICHAM_GLOBAL_BRIDGE_check_permission',
    )
    );

    // GET /hicham_global/v1/capabilities — Detected plugins and available features.
    register_rest_route(
        $namespace,
        '/capabilities',
        array(
        'methods' => WP_REST_Server::READABLE,
        'callback' => 'HICHAM_GLOBAL_BRIDGE_handle_capabilities',
        'permission_callback' => 'HICHAM_GLOBAL_BRIDGE_check_permission',
    )
    );

    // POST /hicham_global/v1/seo — Apply SEO metadata to a post.
    register_rest_route(
        $namespace,
        '/seo',
        array(
        'methods' => WP_REST_Server::CREATABLE,
        'callback' => 'HICHAM_GLOBAL_BRIDGE_handle_seo',
        'permission_callback' => 'HICHAM_GLOBAL_BRIDGE_check_permission',
    )
    );

    // POST /hicham_global/v1/recipe — Create a recipe card for a post.
    register_rest_route(
        $namespace,
        '/recipe',
        array(
        'methods' => WP_REST_Server::CREATABLE,
        'callback' => 'HICHAM_GLOBAL_BRIDGE_handle_recipe',
        'permission_callback' => 'HICHAM_GLOBAL_BRIDGE_check_permission',
    )
    );
}
add_action('rest_api_init', 'HICHAM_GLOBAL_BRIDGE_register_routes');

/**
 * Handle GET /hicham_global/v1/status
 *
 * Returns the bridge health status, plugin version,
 * and the number of active supported plugins.
 *
 * @param WP_REST_Request $request The incoming request.
 * @return WP_REST_Response
 */
function HICHAM_GLOBAL_BRIDGE_handle_status($request)
{
    $active_plugins = HICHAM_GLOBAL_BRIDGE_get_active_plugins();

    $data = array(
        'plugin' => 'Hicham Global Bridge',
        'version' => HICHAM_GLOBAL_BRIDGE_VERSION,
        'status' => count($active_plugins) > 0 ? 'active' : 'inactive',
        'active_adapters' => count($active_plugins),
        'wordpress' => get_bloginfo('version'),
        'php' => phpversion(),
    );

    return new WP_REST_Response($data, 200);
}

/**
 * Handle GET /hicham_global/v1/capabilities
 *
 * Returns the full list of detected plugins and their capabilities.
 *
 * @param WP_REST_Request $request The incoming request.
 * @return WP_REST_Response
 */
function HICHAM_GLOBAL_BRIDGE_handle_capabilities($request)
{
    $detected_plugins = HICHAM_GLOBAL_BRIDGE_detect_plugins();
    $capabilities_map = require HICHAM_GLOBAL_BRIDGE_PATH . 'registry/capabilities.php';
    $active_capabilities = array();

    foreach ($capabilities_map as $module => $config) {
        $module_active = false;
        $active_adapters = array();

        foreach ($config['adapters'] as $adapter_slug) {
            if (isset($detected_plugins[$adapter_slug]) && $detected_plugins[$adapter_slug]['active']) {
                $module_active = true;
                $active_adapters[] = $adapter_slug;
            }
        }

        $active_capabilities[$module] = array(
            'available' => $module_active,
            'active_adapters' => $active_adapters,
            'fields' => $config['fields'],
        );
    }

    $data = array(
        'plugins' => $detected_plugins,
        'capabilities' => $active_capabilities,
    );

    return new WP_REST_Response($data, 200);
}
